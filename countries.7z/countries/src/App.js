import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import CountriesList from "./pages/CountriesList";
import CountryDetail from "./pages/CountryDetail";
import Container from '@mui/material/Container';

function App() {
  return (
    <Router>
      <Container maxWidth="md" sx={{ py: 4 }}>
        <Routes>
          <Route path="/" element={<CountriesList />} />
          <Route path="/country/:code" element={<CountryDetail />} />
        </Routes>
      </Container>
    </Router>
  );
}

export default App;
