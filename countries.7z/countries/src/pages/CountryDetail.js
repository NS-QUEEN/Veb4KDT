import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Card, CardContent, Typography, Stack, Button } from "@mui/material";

function CountryDetail() {
  const { code } = useParams();
  const [country, setCountry] = useState(null);

  useEffect(() => {
    fetch(`https://restcountries.com/v3.1/alpha/${code}?fields=name,capital,flags,cca3,population,area,languages,currencies`)
      .then((res) => {
        console.log('Fetch response:', res);
        return res.json();
      })
      .then((data) => {
        console.log('Country data:', data);
        setCountry(data);
      })
      .catch((error) => {
        console.error('Fetch error:', error);
        setCountry(null);
      });
  }, [code]);

  if (!country) return <div>Laadimine...</div>;

  return (
    <Card>
      <CardContent>
        <Stack spacing={2}>
          <img src={country.flags.png} alt="flag" width={100} />
          <Typography variant="h5">{country.name.common}</Typography>
          <Typography>Pealinn: {country.capital?.[0] || "Puudub"}</Typography>
          <Typography>Rahvaarv: {country.population.toLocaleString()}</Typography>
          <Typography>Pindala: {country.area.toLocaleString()} km²</Typography>
          <Typography>Keeled: {country.languages ? Object.values(country.languages).join(", ") : "Puuduvad"}</Typography>
          <Typography>Valuutad: {country.currencies ? Object.values(country.currencies).map(v => v.name).join(", ") : "Puuduvad"}</Typography>
          <Button variant="outlined" component={Link} to="/">Tagasi</Button>
        </Stack>
      </CardContent>
    </Card>
  );
}

export default CountryDetail;