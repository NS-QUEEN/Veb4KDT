import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { TextField, Pagination, Card, CardContent, Typography, Stack } from "@mui/material";

const PAGE_SIZE = 10;

function CountriesList() {
  const [search, setSearch] = useState("");
  const [countries, setCountries] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [page, setPage] = useState(1);

  useEffect(() => {
    fetch("https://restcountries.com/v3.1/all?fields=name,capital,flags,cca3,population,area,languages,currencies")
      .then((res) => res.json())
      .then((data) => { 
        console.log("Countries loaded:", data); 
        setCountries(Array.isArray(data) ? data : []);
      });
  }, []);

  useEffect(() => {
    const res = (Array.isArray(countries) ? countries : []).filter((c) =>
      c.name.common.toLowerCase().includes(search.toLowerCase())
    );
    setFiltered(res);
    setPage(1);
  }, [search, countries]);

  /*
  useEffect(() => {
    if (Array.isArray(countries)) {
      const res = countries.filter((c) =>
        c.name.common.toLowerCase().includes(search.toLowerCase())
      );
      setFiltered(res);
      setPage(1);
    } else {
      setFiltered([]);
    }
  }, [search, countries]);
  */

  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  return (
    <Stack spacing={2}>
      <TextField
        label="Otsi riiki"
        variant="outlined"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <Stack spacing={2}>
        {paginated.map((country) => (
          <Card key={country.cca3} variant="outlined">
            <CardContent>
              <Link to={`/country/${country.cca3}`} style={{ textDecoration: 'none' }}>
                <Typography variant="h6">{country.name.common}</Typography>
                <Typography variant="body2">{country.capital?.[0] || "Pealinn puudub"}</Typography>
              </Link>
            </CardContent>
          </Card>
        ))}
      </Stack>
      <Pagination
        count={Math.ceil(filtered.length / PAGE_SIZE)}
        page={page}
        onChange={(e, val) => setPage(val)}
        color="primary"
      />
    </Stack>
  );
}

export default CountriesList;